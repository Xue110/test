

// 处理文件选择事件的函数
function handleFileSelect(event) {
 var file = event.target.files[0]; // 获取用户选择的文件
var reader = new FileReader(); // 创建一个 FileReader 对象

// 文件读取完成后的回调函数
reader.onload = function(e) {
 let imgContainer = document.querySelector('.image-container'); // 获取图片容器元素
 var imgElement = document.createElement("img"); // 创建一个 img 元素
 imgElement.src = e.target.result; // 设置 img 元素的 src 属性为文件内容
let imgCl = imgContainer.appendChild(imgElement); // 将 img 元素添加到图片容器中
// let box = document.querySelector('.box1')
// let style = document.querySelector('.style')
// imgCl.setAttribute('data-search','')
// imgCl.setAttribute("data-cat","scenery"); // 设置 img 元素的自定义属性 data-cat 为 "animal"
//  imgCl.setAttribute("alt", ""); // 设置 img 元素的 alt 属性为空字符串

 box.onclick = () =>{
      
 }

 const arr = JSON.parse(localStorage.getItem('imageData')) || []; // 从本地存储中获取图片信息数组，如果为空则初始化为空数组
 const newObj = {
src: imgCl.src,

 };
 arr.push(newObj); // 将新的图片信息对象添加到数组中
 localStorage.setItem('imageData', JSON.stringify(arr)); // 将更新后的图片信息数组存储在本地存储中
};
 
reader.readAsDataURL(file); // 以DataURL格式读取用户选择的文件
   }
   // 从本地存储中获取图片信息并显示在页面上
   const arr = JSON.parse(localStorage.getItem('imageData')) || []; // 从本地存储中获取存储的图片信息，如果为空则初始化为空数组
   let imgContainer = document.querySelector('.image-container'); // 获取用于显示图片的容器元素
   
   // 遍历存储在本地存储中的图片信息数组，并逐个创建对应的 img 元素显示在页面上
   arr.forEach(image => {
 const imgElement = document.createElement("img"); // 创建一个新的 img 元素
 imgElement.src = image.src; // 设置 img 元素的 src 属性为图片的链接
  imgElement.setAttribute("data-cat", "scenery"); // 设置 img 元素的自定义属性 data-cat 为 "animal"
 imgElement.setAttribute("alt", ""); // 设置 img 元素的 alt 属性为空字符串（可根据需要修改）
   
 imgContainer.appendChild(imgElement); // 将创建的 img 元素添加到图片容器中
 
   });



let galleryImages = document.querySelectorAll('.image-container img');
let imagePop = document.querySelector('.image-popup');
galleryImages.forEach(img =>{
   img.onclick = () =>{
      let imageSrc = img.getAttribute('src');
      imagePop.style.display = 'flex';
      imagePop.querySelector('img').src = imageSrc;
   };
});
imagePop.onclick = () =>{
   imagePop.style.display = 'none';
};
document.querySelector('#search-box').oninput = () =>{
   var value = document.querySelector('#search-box').value.toLowerCase();
   galleryImages.forEach(img =>{
      var filter = img.getAttribute('data-search').toLowerCase();
      if(filter.indexOf(value) > -1){
         img.style.display = 'block';
      }else{
         img.style.display = 'none';
      };
   });
};
let categoryBtn = document.querySelectorAll('.category .btn');
categoryBtn.forEach(btn =>{
   btn.onclick = () =>{
      categoryBtn.forEach(remove => remove.classList.remove('active'));
      let dataCategory = btn.getAttribute('data-category');
      galleryImages.forEach(img =>{
         var imgCat = img.getAttribute('data-cat');
         if(dataCategory == 'all'){
            img.style.display = 'block';
         }else if(dataCategory == imgCat){
            img.style.display = 'block';
         }else{
            img.style.display = 'none';
         }
      });
      btn.classList.add('active');
   };
});
let typeBtn = document.querySelectorAll('.type .btn');
typeBtn.forEach(btn =>{
   btn.onclick = () =>{
      typeBtn.forEach(remove => remove.classList.remove('active'));
      let datatype = btn.getAttribute('data-type');
      galleryImages.forEach(img =>{
         var imgtype = img.getAttribute('src').split('.').pop();
         if(datatype == 'all'){
            img.style.display = 'block';
         }else if(datatype == imgtype){
            img.style.display = 'block';
         }else{
            img.style.display = 'none';
         }
      });
      btn.classList.add('active');
   };
});
document.querySelector('.reset-btn .btn').onclick = () =>{
   window.location.reload();
};




